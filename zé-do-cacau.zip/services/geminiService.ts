
import { GoogleGenAI, Type } from "@google/genai";
import type { CocoaQuantity } from '../types';

// Tenta obter a chave de diferentes fontes para compatibilidade (Local vs Produção/Vite)
// @ts-ignore
const API_KEY = import.meta.env?.VITE_API_KEY || process.env.API_KEY;

// No código de produção, não lançamos erro imediatamente para não quebrar o app inteiro se a chave faltar,
// mas as chamadas de IA falharão.
const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

const schema = {
    type: Type.OBJECT,
    properties: {
        fullBags: {
            type: Type.INTEGER,
            description: "O número total de sacas cheias de 60kg mencionadas. Se nenhuma, retorne 0."
        },
        partialBagWeight: {
            type: Type.NUMBER,
            description: "O peso em quilogramas da última saca incompleta. Se nenhuma, retorne 0."
        }
    },
    required: ["fullBags", "partialBagWeight"]
};


export const parseCocoaQuantityFromText = async (text: string): Promise<CocoaQuantity> => {
    if (!ai) {
        throw new Error("Chave de API não configurada. Configure VITE_API_KEY no seu provedor de hospedagem.");
    }

    try {
        const prompt = `
            Analyze the following text from a cocoa farmer and extract the quantity of cocoa. 
            A full bag ("saca") always weighs 60kg. Identify the number of full 60kg bags and the weight of any remaining partial bag.
            
            Examples:
            - "5 sacas e 30kg" -> { "fullBags": 5, "partialBagWeight": 30 }
            - "deu 12 sacas e uma de 45 quilos" -> { "fullBags": 12, "partialBagWeight": 45 }
            - "7 sacas completas" -> { "fullBags": 7, "partialBagWeight": 0 }
            - "uma saca de 25kg" -> { "fullBags": 0, "partialBagWeight": 25 }
            - "8 sacas e meia" -> { "fullBags": 8, "partialBagWeight": 30 }
            - "200kg" -> { "fullBags": 3, "partialBagWeight": 20 }

            Text to analyze: "${text}"
        `;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
            }
        });

        const jsonString = response.text.trim();
        const parsedJson = JSON.parse(jsonString);

        return {
            fullBags: parsedJson.fullBags ?? 0,
            partialBagWeight: parsedJson.partialBagWeight ?? 0,
        };

    } catch (error) {
        console.error("Error parsing cocoa quantity with Gemini:", error);
        throw new Error("Falha ao analisar a quantidade. Por favor, insira manualmente ou verifique a conexão.");
    }
};