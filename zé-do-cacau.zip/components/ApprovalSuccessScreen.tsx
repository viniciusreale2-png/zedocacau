import React from 'react';
import type { Company, User } from '../types';
import Button from './common/Button';
import Card from './common/Card';
import Header from './common/Header';
import { WhatsappIcon } from './icons/WhatsappIcon';

interface ApprovalSuccessScreenProps {
  user: User;
  company?: Company;
  onAcknowledge: (user: User) => void;
}

const ApprovalSuccessScreen: React.FC<ApprovalSuccessScreenProps> = ({ 
    user,
    company,
    onAcknowledge
}) => {

    const formatPhoneNumberForWhatsApp = (phone: string): string => {
        const digitsOnly = phone.replace(/\D/g, '');
        if (digitsOnly.length === 11 && !digitsOnly.startsWith('55')) {
            return `55${digitsOnly}`;
        }
        return digitsOnly;
    };

    const message = `Olá, ${user.fullName}! Seu cadastro na empresa ${company?.name || 'parceira'} foi aprovado com sucesso no aplicativo ZÉ DO CACAU. Você já pode começar a agendar suas coletas!`;
    const whatsappUrl = `https://wa.me/${formatPhoneNumberForWhatsApp(user.phone)}?text=${encodeURIComponent(message)}`;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <Header />
      <Card className="w-full max-w-md mt-6 text-center">
        <div className="mx-auto bg-green-100 rounded-full h-16 w-16 flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <h2 className="text-2xl font-bold text-stone-800 mb-2">Cadastro Aprovado!</h2>
        <p className="text-stone-500 mb-6">Bem-vindo, {user.fullName}! Sua conta foi ativada pela empresa {company?.name}.</p>
        
        <a 
            href={whatsappUrl} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="w-full inline-block"
        >
            <Button className="w-full mb-3">
                <WhatsappIcon className="w-5 h-5 mr-2" />
                Receber Notificação no WhatsApp
            </Button>
        </a>
        <Button onClick={() => onAcknowledge(user)} className="w-full bg-stone-700 hover:bg-stone-800">
            Acessar o Aplicativo
        </Button>
      </Card>
    </div>
  );
};

export default ApprovalSuccessScreen;