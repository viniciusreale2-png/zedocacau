
import React, { useState, useCallback, useEffect } from 'react';
import type { PickupRequest } from '../types';
import { parseCocoaQuantityFromText } from '../services/geminiService';
import Button from './common/Button';
import { SparklesIcon } from './icons/SparklesIcon';
import { UploadIcon } from './icons/UploadIcon';
import Input from './common/Input';
import Header from './common/Header';
import { LocationMarkerIcon } from './icons/LocationMarkerIcon';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';

interface SchedulePickupFormProps {
  onSave: (pickup: Omit<PickupRequest, 'id' | 'userId' | 'companyId' | 'status'>) => void;
  onCancel: () => void;
  initialData?: PickupRequest | null;
}

const SchedulePickupForm: React.FC<SchedulePickupFormProps> = ({ onSave, onCancel, initialData }) => {
  const [naturalLanguageInput, setNaturalLanguageInput] = useState('');
  const [fullBags, setFullBags] = useState(0);
  const [partialBagWeight, setPartialBagWeight] = useState(0);
  const [address, setAddress] = useState('');
  const [coordinates, setCoordinates] = useState<{latitude: number; longitude: number} | undefined>(undefined);
  const [pickupDate, setPickupDate] = useState('');
  const [pickupTime, setPickupTime] = useState('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [error, setError] = useState('');

  const totalWeight = (fullBags * 60) + partialBagWeight;

  useEffect(() => {
    if (initialData) {
        setFullBags(initialData.fullBags);
        setPartialBagWeight(initialData.partialBagWeight);
        setAddress(initialData.address);
        setCoordinates(initialData.coordinates);
        const date = new Date(initialData.pickupDate);
        setPickupDate(date.toISOString().split('T')[0]);
        setPickupTime(date.toTimeString().substring(0, 5));
        setPhotoPreview(initialData.photoUrl);
    } else {
        const today = new Date().toISOString().split('T')[0];
        setPickupDate(today);
        const now = new Date();
        now.setHours(now.getHours() + 2);
        const twoHoursFromNow = now.toTimeString().substring(0,5);
        setPickupTime(twoHoursFromNow);
    }
  }, [initialData]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleParseWithAI = useCallback(async () => {
    if (!naturalLanguageInput) return;
    setIsParsing(true);
    setError('');
    try {
      const result = await parseCocoaQuantityFromText(naturalLanguageInput);
      setFullBags(result.fullBags);
      setPartialBagWeight(result.partialBagWeight);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsParsing(false);
    }
  }, [naturalLanguageInput]);
  
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
        setError('Geolocalização não é suportada pelo seu navegador.');
        return;
    }
    setIsGettingLocation(true);
    setError('');
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const { latitude, longitude } = position.coords;
            setCoordinates({ latitude, longitude });
            setAddress(`Coordenadas: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
            setIsGettingLocation(false);
        },
        (error) => {
            setError(`Erro ao obter localização: ${error.message}`);
            setIsGettingLocation(false);
        }
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoPreview || !pickupDate || !pickupTime || totalWeight <= 0 || !address.trim()) {
      setError('Por favor, preencha todos os campos, adicione o endereço, envie uma foto e garanta que o peso seja maior que zero.');
      return;
    }
    
    setIsSubmitting(true);
    // Simulate submission delay
    setTimeout(() => {
        const pickupDateTime = new Date(`${pickupDate}T${pickupTime}`);
        onSave({
            fullBags,
            partialBagWeight,
            totalWeight,
            address: address.trim(),
            coordinates,
            photoUrl: photoPreview!, // In a real app, this would be an uploaded URL
            pickupDate: pickupDateTime.toISOString(),
        });
        setIsSubmitting(false);
    }, 1500);
  };
  

  return (
    <div>
        <div className="flex items-center mb-6">
            <button 
              onClick={onCancel} 
              className="mr-3 p-2 rounded-full hover:bg-stone-200 transition-colors text-stone-600"
              aria-label="Voltar"
            >
              <ArrowLeftIcon className="w-6 h-6" />
            </button>
            <Header />
        </div>
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg">
            <h2 className="text-2xl font-bold text-stone-800 mb-4">
                {initialData ? 'Editar Agendamento' : 'Novo Pedido de Coleta'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-6">

                <div>
                    <label className="block text-sm font-medium text-stone-600 mb-1">Descreva a Quantidade (com IA)</label>
                    <div className="flex space-x-2">
                        <Input 
                            type="text"
                            value={naturalLanguageInput}
                            onChange={(e) => setNaturalLanguageInput(e.target.value)}
                            placeholder="ex: '5 sacas e 20kg'"
                            className="flex-grow"
                        />
                        <Button type="button" onClick={handleParseWithAI} disabled={isParsing || !naturalLanguageInput} className="w-auto px-4">
                            {isParsing ? '...' : <SparklesIcon className="w-5 h-5"/>}
                        </Button>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-stone-600 mb-1">Sacas Cheias (60kg)</label>
                        <Input type="number" value={fullBags} onChange={(e) => setFullBags(Number(e.target.value))} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-stone-600 mb-1">Saca Parcial (kg)</label>
                        <Input type="number" value={partialBagWeight} onChange={(e) => setPartialBagWeight(Number(e.target.value))} />
                    </div>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg text-center">
                    <p className="text-sm font-medium text-green-700">Peso Total Estimado</p>
                    <p className="text-3xl font-bold text-green-800">{totalWeight} kg</p>
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-stone-600 mb-1">Endereço de Coleta</label>
                    <div className="flex space-x-2">
                        <Input 
                            type="text"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            placeholder="Rua, número, ponto de referência..."
                            className="flex-grow"
                            required
                        />
                        <Button type="button" onClick={handleGetLocation} disabled={isGettingLocation} className="w-auto px-4">
                            {isGettingLocation ? '...' : <LocationMarkerIcon className="w-5 h-5"/>}
                        </Button>
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-stone-600 mb-1">Foto das Sacas</label>
                    <label htmlFor="photo-upload" className="flex justify-center w-full h-32 px-4 transition bg-white border-2 border-stone-300 border-dashed rounded-md appearance-none cursor-pointer hover:border-stone-400 focus:outline-none">
                        {photoPreview ? (
                            <img src={photoPreview} alt="Pré-visualização das sacas de cacau" className="h-full w-full object-contain rounded-md" />
                        ) : (
                            <span className="flex items-center space-x-2">
                                <UploadIcon className="w-6 h-6 text-stone-500" />
                                <span className="font-medium text-stone-500">
                                    Clique para enviar uma foto
                                </span>
                            </span>
                        )}
                        <input id="photo-upload" type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
                    </label>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-stone-600 mb-1">Data da Coleta</label>
                        <Input type="date" value={pickupDate} onChange={(e) => setPickupDate(e.target.value)} min={new Date().toISOString().split('T')[0]} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-stone-600 mb-1">Hora da Coleta</label>
                        <Input type="time" value={pickupTime} onChange={(e) => setPickupTime(e.target.value)} />
                    </div>
                </div>

                {error && <p className="text-red-600 text-sm text-center">{error}</p>}
                
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                    <Button type="button" onClick={onCancel} className="w-full bg-stone-200 text-stone-700 hover:bg-stone-300">Cancelar</Button>
                    <Button type="submit" disabled={isSubmitting} className="w-full">
                        {isSubmitting ? (initialData ? 'Salvando...' : 'Agendando...') : (initialData ? 'Salvar Alterações' : 'Confirmar Agendamento')}
                    </Button>
                </div>
            </form>
        </div>
    </div>
  );
};

export default SchedulePickupForm;
