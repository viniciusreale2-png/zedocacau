
import React, { useState } from 'react';
import type { User, Company, PickupRequest } from '../types';
import Header from './common/Header';
import Button from './common/Button';
import Card from './common/Card';
import { CalendarIcon } from './icons/CalendarIcon';
import { EditIcon } from './icons/EditIcon';
import { TrashIcon } from './icons/TrashIcon';
import { WhatsappIcon } from './icons/WhatsappIcon';
import Input from './common/Input';

interface DashboardScreenProps {
  user: User;
  company?: Company;
  pickupRequests: PickupRequest[];
  onScheduleNew: () => void;
  onLogout: () => void;
  onEdit: (pickup: PickupRequest) => void;
  onDelete: (pickupId: string) => void;
  onCompletePickup: (pickupId: string, code: string) => {success: boolean, error?: string};
}

const DashboardScreen: React.FC<DashboardScreenProps> = ({ user, company, pickupRequests, onScheduleNew, onLogout, onEdit, onDelete, onCompletePickup }) => {
  const [confirmingPickupId, setConfirmingPickupId] = useState<string | null>(null);
  const [confirmationCodeInput, setConfirmationCodeInput] = useState('');
  const [confirmationError, setConfirmationError] = useState('');

  const getStatusChip = (status: PickupRequest['status']) => {
    switch (status) {
      case 'Agendado':
        return <span className="text-xs font-medium bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{status}</span>;
      case 'Confirmado':
        return <span className="text-xs font-medium bg-teal-100 text-teal-800 px-2 py-1 rounded-full">{status}</span>;
       case 'Reagendamento Proposto':
        return <span className="text-xs font-medium bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full whitespace-nowrap">Proposta de Reagendamento</span>;
      case 'Concluído':
        return <span className="text-xs font-medium bg-green-100 text-green-800 px-2 py-1 rounded-full">{status}</span>;
      case 'Cancelado':
        return <span className="text-xs font-medium bg-red-100 text-red-800 px-2 py-1 rounded-full">{status}</span>;
    }
  }

    const formatPhoneNumberForWhatsApp = (phone: string): string => {
        const digitsOnly = phone.replace(/\D/g, '');
        if (digitsOnly.length === 11 && !digitsOnly.startsWith('55')) {
            return `55${digitsOnly}`;
        }
        return digitsOnly;
    };
    
    const handleConfirmPickupClick = (pickupId: string) => {
        setConfirmingPickupId(pickupId);
        setConfirmationCodeInput('');
        setConfirmationError('');
    }

    const handleFinalizeConfirmation = (pickupId: string) => {
        const result = onCompletePickup(pickupId, confirmationCodeInput);
        if (result.success) {
            setConfirmingPickupId(null);
        } else {
            setConfirmationError(result.error || 'Código inválido.');
        }
    }


  return (
    <div>
        <div className="flex justify-between items-center mb-6">
            <Header />
            <button 
              onClick={onLogout} 
              className="px-4 py-2 text-sm font-medium text-red-700 bg-red-100 hover:bg-red-200 rounded-lg transition-colors"
            >
              Sair
            </button>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-md mb-8">
            <h1 className="text-2xl font-bold text-stone-800">Olá, {user.fullName}!</h1>
            <p className="text-stone-500">Afiliado a: <span className="font-semibold">{company?.name || 'N/A'}</span></p>
        </div>

        <div className="mb-8">
            <Button onClick={onScheduleNew} className="w-full text-lg">
                <CalendarIcon className="w-5 h-5 mr-2" />
                Agendar Nova Coleta
            </Button>
        </div>

        <div>
            <h2 className="text-xl font-bold text-stone-700 mb-4">Histórico de Coletas</h2>
            {pickupRequests.length > 0 ? (
                <div className="space-y-4">
                    {pickupRequests.map(request => (
                        <Card key={request.id}>
                            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start">
                                <div>
                                    <p className="font-bold text-lg text-green-800">
                                        {request.totalWeight} kg
                                    </p>
                                    <p className="text-sm text-stone-500">
                                        {new Date(request.pickupDate).toLocaleString('pt-BR', { dateStyle: 'long', timeStyle: 'short' })}
                                    </p>
                                    <p className="text-sm text-stone-500 mt-1">
                                      {request.fullBags} sacas cheias, {request.partialBagWeight}kg parcial
                                    </p>
                                    <p className="text-sm text-stone-500 mt-1 truncate">
                                      Endereço: {request.address}
                                    </p>
                                </div>
                                <div className="mt-4 sm:mt-0">
                                    {getStatusChip(request.status)}
                                </div>
                            </div>
                            
                            <img src={request.photoUrl} alt="Sacas de cacau" className="mt-4 rounded-lg w-full h-40 object-cover" />
                            
                            {confirmingPickupId === request.id ? (
                                <div className="mt-4 pt-4 border-t border-dashed border-stone-200 space-y-3">
                                    <label className="block text-sm font-medium text-stone-700">Digite o código de segurança fornecido pelo motorista para confirmar a coleta:</label>
                                    <Input 
                                        type="text"
                                        placeholder="Ex: CACAU-1234"
                                        value={confirmationCodeInput}
                                        onChange={e => {
                                            setConfirmationCodeInput(e.target.value.toUpperCase());
                                            setConfirmationError('');
                                        }}
                                    />
                                    {confirmationError && <p className="text-xs text-red-600 text-center">{confirmationError}</p>}
                                    <div className="flex gap-2">
                                        <Button onClick={() => setConfirmingPickupId(null)} className="w-full !bg-stone-200 !text-stone-700 hover:!bg-stone-300">Cancelar</Button>
                                        <Button onClick={() => handleFinalizeConfirmation(request.id)} className="w-full">Finalizar</Button>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex justify-end space-x-2 mt-4 pt-4 border-t border-stone-100">
                                    {request.status === 'Agendado' && (
                                        <>
                                            <button 
                                                onClick={() => onEdit(request)} 
                                                className="p-2 rounded-full hover:bg-stone-100 text-stone-600 transition-colors"
                                                aria-label="Editar"
                                            >
                                                <EditIcon className="w-5 h-5" />
                                            </button>
                                            <button 
                                                onClick={() => {
                                                    if (window.confirm('Tem certeza que deseja excluir este agendamento?')) {
                                                        onDelete(request.id)
                                                    }
                                                }}
                                                className="p-2 rounded-full hover:bg-stone-100 text-red-600 transition-colors"
                                                aria-label="Excluir"
                                            >
                                                <TrashIcon className="w-5 h-5" />
                                            </button>
                                        </>
                                    )}
                                    {request.status === 'Confirmado' && (
                                        <Button onClick={() => handleConfirmPickupClick(request.id)} className="w-full">
                                            Confirmar Coleta
                                        </Button>
                                    )}
                                    {request.status === 'Reagendamento Proposto' && company && (
                                        <a 
                                            href={`https://wa.me/${formatPhoneNumberForWhatsApp(company.phone)}?text=${encodeURIComponent(`Olá, ${company.name}! Recebi a proposta de reagendamento para a coleta de ${request.totalWeight}kg. Podemos confirmar para ${new Date(request.pickupDate).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}?`)}`}
                                            target="_blank" 
                                            rel="noopener noreferrer" 
                                            className="w-full inline-block"
                                        >
                                            <Button className="w-full !bg-yellow-500 hover:!bg-yellow-600 text-white">
                                                <WhatsappIcon className="w-5 h-5 mr-2" />
                                                Responder Proposta via WhatsApp
                                            </Button>
                                        </a>
                                    )}
                                </div>
                            )}
                        </Card>
                    ))}
                </div>
            ) : (
                <Card>
                    <p className="text-center text-stone-500">Você não tem coletas agendadas.</p>
                </Card>
            )}
        </div>
    </div>
  );
};

export default DashboardScreen;
