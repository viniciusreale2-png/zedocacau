
import React, { useState } from 'react';
import type { Company, PickupRequest, User } from '../types';
import Button from './common/Button';
import Card from './common/Card';
import Header from './common/Header';
import { WhatsappIcon } from './icons/WhatsappIcon';
import { UploadIcon } from './icons/UploadIcon';

interface ScheduleSuccessScreenProps {
  pickupRequest: PickupRequest;
  company: Company;
  user: User;
  onReturnToDashboard: () => void;
}

const ScheduleSuccessScreen: React.FC<ScheduleSuccessScreenProps> = ({ 
    pickupRequest, 
    company,
    user,
    onReturnToDashboard 
}) => {
    const [isSharing, setIsSharing] = useState(false);

    const formatPhoneNumberForWhatsApp = (phone: string): string => {
        const digitsOnly = phone.replace(/\D/g, '');
        if (digitsOnly.length === 11 && !digitsOnly.startsWith('55')) {
            return `55${digitsOnly}`;
        }
        if (digitsOnly.length === 13 && digitsOnly.startsWith('55')) {
            return digitsOnly;
        }
        return digitsOnly;
    };

    const formattedDate = new Date(pickupRequest.pickupDate).toLocaleString('pt-BR', {
        dateStyle: 'full',
        timeStyle: 'short'
    });
    
    let locationInfo = `*Endereço:* ${pickupRequest.address}`;
    if (pickupRequest.coordinates) {
        const { latitude, longitude } = pickupRequest.coordinates;
        locationInfo += `\n*Ver no mapa:* https://www.google.com/maps?q=${latitude},${longitude}`;
    }

    // Updated message to prompt company to check the app
    const messageText = `Olá, ${company.name}!\n\nAcabei de registrar um pedido no aplicativo *Zé do Cacau*.\n\n*Cliente:* ${user.fullName}\n*Peso Total:* ${pickupRequest.totalWeight} kg\n*Detalhes:* ${pickupRequest.fullBags} sacas cheias e ${pickupRequest.partialBagWeight}kg\n*Data/Hora:* ${formattedDate}\n\nPor favor, acesse o painel da empresa para ver a foto e confirmar a coleta.`;
    
    // Direct link matches the company's phone exactly.
    const whatsappUrl = `https://wa.me/${formatPhoneNumberForWhatsApp(company.phone)}?text=${encodeURIComponent(messageText)}`;

    const handleDirectWhatsApp = () => {
        window.open(whatsappUrl, '_blank');
    }

    const handleNativeShare = async () => {
        setIsSharing(true);
        try {
            let filesArray: File[] = [];

            // Try to convert photoUrl to a file if it exists
            if (pickupRequest.photoUrl) {
                try {
                    const response = await fetch(pickupRequest.photoUrl);
                    const blob = await response.blob();
                    const file = new File([blob], "coleta_cacau.jpg", { type: blob.type });
                    filesArray = [file];
                } catch (e) {
                    console.log("Could not prepare image for sharing:", e);
                }
            }

            const shareData: ShareData = {
                title: 'Coleta Zé do Cacau',
                text: messageText,
            };

            if (filesArray.length > 0 && navigator.canShare && navigator.canShare({ files: filesArray })) {
                 await navigator.share({
                    ...shareData,
                    files: filesArray
                 });
            } else {
               alert("Seu dispositivo não suporta o compartilhamento direto de imagens. Use o botão principal para abrir o WhatsApp.");
            }
        } catch (error) {
             if ((error as Error).name !== 'AbortError') {
                 console.error("Error sharing", error);
             }
        } finally {
            setIsSharing(false);
        }
    };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <Header />
      <Card className="w-full max-w-md mt-6 text-center">
        <div className="mx-auto bg-green-100 rounded-full h-16 w-16 flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
        </div>
        <h2 className="text-2xl font-bold text-stone-800 mb-2">Agendamento Confirmado!</h2>
        <p className="text-stone-500 mb-6">Seu pedido foi registrado. A notificação foi enviada para o aplicativo da empresa.</p>
        
        <div className="bg-stone-50 p-4 rounded-lg text-left mb-6 space-y-2">
            <p><span className="font-semibold text-stone-600">Peso:</span> {pickupRequest.totalWeight} kg</p>
            <p><span className="font-semibold text-stone-600">Data:</span> {formattedDate}</p>
            <p><span className="font-semibold text-stone-600">Empresa:</span> {company.name}</p>
        </div>

        <Button 
            onClick={handleDirectWhatsApp}
            className="w-full mb-3 flex items-center justify-center"
        >
            <WhatsappIcon className="w-5 h-5 mr-2" />
            Avisar no WhatsApp (Recomendado)
        </Button>

        <button 
            onClick={handleNativeShare}
            disabled={isSharing}
            className="w-full mb-4 py-3 flex items-center justify-center text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors font-medium text-sm"
        >
            <UploadIcon className="w-4 h-4 mr-2" />
            {isSharing ? 'Abrindo...' : 'Opcional: Compartilhar Foto (Escolher Contato)'}
        </button>
        
        <p className="text-xs text-stone-400 mb-4 px-4">
            *Ao clicar no botão verde, você enviará uma mensagem pedindo para a empresa confirmar sua coleta pelo aplicativo.
        </p>

        <Button onClick={onReturnToDashboard} className="w-full !bg-stone-200 !text-stone-700 hover:!bg-stone-300">
            Voltar para o Painel
        </Button>
      </Card>
    </div>
  );
};

export default ScheduleSuccessScreen;
