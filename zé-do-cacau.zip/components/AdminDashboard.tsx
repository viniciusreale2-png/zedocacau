
import React, { useState } from 'react';
import type { Company } from '../types';
import Header from './common/Header';
import Button from './common/Button';
import Input from './common/Input';
import Card from './common/Card';
import { EyeIcon } from './icons/EyeIcon';
import { EyeOffIcon } from './icons/EyeOffIcon';
import { EditIcon } from './icons/EditIcon';

interface AdminDashboardProps {
  companies: Company[];
  onAddCompany: (companyData: Omit<Company, 'id'>) => void;
  onUpdateCompany: (company: Company) => void;
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
    companies, 
    onAddCompany, 
    onUpdateCompany,
    onLogout,
}) => {
  const [editingCompanyId, setEditingCompanyId] = useState<string | null>(null);
  
  const [newCompanyName, setNewCompanyName] = useState('');
  const [newManagerName, setNewManagerName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);

  const resetForm = () => {
    setEditingCompanyId(null);
    setNewCompanyName('');
    setNewManagerName('');
    setNewPhone('');
    setNewUsername('');
    setNewPassword('');
  };

  const handleEditClick = (company: Company) => {
    setEditingCompanyId(company.id);
    setNewCompanyName(company.name);
    setNewManagerName(company.managerName);
    setNewPhone(company.phone);
    setNewUsername(company.username);
    setNewPassword(company.password || '');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCompanyName.trim() && newManagerName.trim() && newPhone.trim() && newUsername.trim()) {
      if (editingCompanyId) {
        // Edit Mode
        onUpdateCompany({
            id: editingCompanyId,
            name: newCompanyName.trim(),
            managerName: newManagerName.trim(),
            phone: newPhone.trim(),
            username: newUsername.trim(),
            password: newPassword.trim(),
        });
      } else {
        // Add Mode
        if (!newPassword.trim()) {
            alert("A senha é obrigatória para novas empresas.");
            return;
        }
        onAddCompany({
            name: newCompanyName.trim(),
            managerName: newManagerName.trim(),
            phone: newPhone.trim(),
            username: newUsername.trim(),
            password: newPassword.trim(),
        });
      }
      resetForm();
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <Header />
        <button 
          onClick={onLogout} 
          className="px-4 py-2 text-sm font-medium text-red-700 bg-red-100 hover:bg-red-200 rounded-lg transition-colors"
        >
          Sair
        </button>
      </div>
      
      <div className="bg-white p-6 rounded-2xl shadow-md mb-8">
        <h1 className="text-2xl font-bold text-stone-800">Painel do Super Administrador</h1>
        <p className="text-stone-500">Gerencie as empresas parceiras.</p>
      </div>
        <div>
            <Card className="mb-8 border-2 border-stone-100">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-stone-700">
                        {editingCompanyId ? 'Editar Empresa' : 'Cadastrar Nova Empresa'}
                    </h2>
                    {editingCompanyId && (
                        <button onClick={resetForm} className="text-sm text-stone-500 hover:text-red-600">
                            Cancelar Edição
                        </button>
                    )}
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                      type="text"
                      value={newCompanyName}
                      onChange={(e) => setNewCompanyName(e.target.value)}
                      placeholder="Nome da empresa"
                      required
                  />
                  <Input
                      type="text"
                      value={newManagerName}
                      onChange={(e) => setNewManagerName(e.target.value)}
                      placeholder="Gerente Responsável"
                      required
                  />
                   <Input
                      type="text"
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value)}
                      placeholder="Telefone / Whatsapp"
                      required
                  />
                   <Input
                      type="text"
                      value={newUsername}
                      onChange={(e) => setNewUsername(e.target.value)}
                      placeholder="Usuário de acesso para a empresa"
                      required
                  />
                  <div className="relative">
                    <Input
                        type={showNewPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder={editingCompanyId ? "Senha (deixe em branco para manter)" : "Senha de acesso"}
                        required={!editingCompanyId}
                        className="pr-10"
                    />
                    <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute inset-y-0 right-0 flex items-center pr-3 text-stone-500 hover:text-stone-700"
                        aria-label={showNewPassword ? 'Ocultar senha' : 'Mostrar senha'}
                    >
                        {showNewPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                    </button>
                  </div>
                  <div className="flex gap-2">
                        {editingCompanyId && (
                             <Button type="button" onClick={resetForm} className="w-1/3 !bg-stone-200 !text-stone-700 hover:!bg-stone-300">
                                Cancelar
                            </Button>
                        )}
                        <Button type="submit" className="w-full">
                            {editingCompanyId ? 'Salvar Alterações' : 'Cadastrar Empresa'}
                        </Button>
                  </div>
                </form>
            </Card>
            <div>
                <h2 className="text-xl font-bold text-stone-700 mb-4">Empresas Cadastradas</h2>
                <div className="space-y-4">
                    {companies.map(company => (
                        <Card key={company.id}>
                          <div className="flex justify-between items-start">
                              <div>
                                <p className="font-bold text-stone-800 text-lg">{company.name}</p>
                                <p className="text-sm text-stone-600">Gerente: <span className="font-medium">{company.managerName}</span></p>
                                <p className="text-sm text-stone-600">Contato: <span className="font-medium">{company.phone}</span></p>
                                <p className="text-sm text-stone-600">Usuário: <span className="font-medium">{company.username}</span></p>
                              </div>
                              <button 
                                  onClick={() => handleEditClick(company)}
                                  className="p-1.5 rounded-full bg-stone-100 text-stone-600 hover:bg-stone-200 hover:text-stone-800 transition-colors"
                                  title="Editar empresa"
                              >
                                  <EditIcon className="w-5 h-5" />
                              </button>
                          </div>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    </div>
  );
};

export default AdminDashboard;
