
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

const Button: React.FC<ButtonProps> = ({ children, className, ...props }) => {
  return (
    <button
      {...props}
      className={`
        flex items-center justify-center px-6 py-3 border border-transparent 
        text-base font-medium rounded-lg text-white bg-green-800 
        hover:bg-green-900 focus:outline-none focus:ring-2 
        focus:ring-offset-2 focus:ring-green-700 transition-colors duration-200
        disabled:bg-stone-400 disabled:cursor-not-allowed
        ${className}
      `}
    >
      {children}
    </button>
  );
};

export default Button;
