import React from 'react';
import { CocoaPodIcon } from '../icons/CocoaPodIcon';

const Header: React.FC = () => {
  return (
    <div className="flex items-center space-x-3">
      <div className="bg-green-800 p-2 rounded-lg">
        <CocoaPodIcon className="w-6 h-6 text-white" />
      </div>
      <h1 className="text-xl font-bold text-stone-800">
        ZÉ DO CACAU
      </h1>
    </div>
  );
};

export default Header;