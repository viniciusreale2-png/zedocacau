
import React from 'react';

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="m12 3-1.9 4.8-4.8 1.9 4.8 1.9L12 16l1.9-4.8 4.8-1.9-4.8-1.9L12 3z"/>
    <path d="M5 22-2 19l2-3 3 2-3 2z"/>
    <path d="M19 2a3 3 0 0 0 0 4.2 3 3 0 0 0 4.2 0 3 3 0 0 0 0-4.2 3 3 0 0 0-4.2 0z"/>
  </svg>
);
