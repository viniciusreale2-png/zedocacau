
import React, { useState } from 'react';
import type { Company, User, PickupRequest, AppNotification } from '../types';
import Header from './common/Header';
import Button from './common/Button';
import Input from './common/Input';
import Card from './common/Card';
import { WhatsappIcon } from './icons/WhatsappIcon';
import { EyeIcon } from './icons/EyeIcon';
import { EyeOffIcon } from './icons/EyeOffIcon';
import { EditIcon } from './icons/EditIcon';
import { BellIcon } from './icons/BellIcon';

interface CompanyDashboardProps {
  company: Company;
  clients: User[];
  pickups: PickupRequest[];
  notifications: AppNotification[];
  onAddClient: (clientData: Omit<User, 'id' | 'status'>) => void;
  onUpdateClient: (client: User) => void;
  onApproveClient: (clientId: string) => void;
  onLogout: () => void;
  onUpdateRequestStatus: (pickupId: string, status: PickupRequest['status']) => void;
  onUpdatePickupDateTime: (pickupId: string, newDateTime: string) => void;
  onMarkNotificationRead: (id: string) => void;
  onMarkAllNotificationsRead: (companyId: string) => void;
}

const CompanyDashboard: React.FC<CompanyDashboardProps> = ({ 
    company, 
    clients, 
    pickups,
    notifications,
    onAddClient, 
    onUpdateClient,
    onApproveClient, 
    onLogout,
    onUpdateRequestStatus,
    onUpdatePickupDateTime,
    onMarkNotificationRead,
    onMarkAllNotificationsRead
}) => {
  const [activeTab, setActiveTab] = useState<'pickups' | 'clients'>('pickups');
  const [showNotifications, setShowNotifications] = useState(false);
  
  // State for adding/editing a client
  const [editingClientId, setEditingClientId] = useState<string | null>(null);
  const [newClientFullName, setNewClientFullName] = useState('');
  const [newClientNickname, setNewClientNickname] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newClientAddress, setNewClientAddress] = useState('');
  const [newClientPassword, setNewClientPassword] = useState('');
  const [showNewClientPassword, setShowNewClientPassword] = useState(false);

  // State for editing a pickup
  const [editingPickupId, setEditingPickupId] = useState<string | null>(null);
  const [newPickupDate, setNewPickupDate] = useState('');
  const [newPickupTime, setNewPickupTime] = useState('');
  
  const getClientById = (id: string) => clients.find(c => c.id === id);
  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  const resetClientForm = () => {
      setEditingClientId(null);
      setNewClientFullName('');
      setNewClientNickname('');
      setNewClientPhone('');
      setNewClientAddress('');
      setNewClientPassword('');
  };

  const handleClientFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newClientFullName.trim() && newClientNickname.trim() && newClientPhone.trim() && newClientAddress.trim()) {
        if (editingClientId) {
            // Updating existing client
            const existingClient = clients.find(c => c.id === editingClientId);
            if (existingClient) {
                onUpdateClient({
                    ...existingClient,
                    fullName: newClientFullName.trim(),
                    name: newClientNickname.trim(),
                    phone: newClientPhone.trim(),
                    address: newClientAddress.trim(),
                    password: newClientPassword.trim() || existingClient.password, // Keep old password if empty
                });
            }
        } else {
            // Creating new client
            if (!newClientPassword.trim()) {
                alert("Senha é obrigatória para novos clientes.");
                return;
            }
            onAddClient({
                name: newClientNickname.trim(),
                fullName: newClientFullName.trim(),
                phone: newClientPhone.trim(),
                address: newClientAddress.trim(),
                password: newClientPassword.trim(),
                companyId: company.id,
            });
        }
        resetClientForm();
    }
  };

  const handleEditClientClick = (client: User) => {
    setEditingClientId(client.id);
    setNewClientFullName(client.fullName);
    setNewClientNickname(client.name);
    setNewClientPhone(client.phone);
    setNewClientAddress(client.address);
    setNewClientPassword(client.password || '');
    // Scroll to top to show form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEditPickupClick = (pickup: PickupRequest) => {
    setEditingPickupId(pickup.id);
    const date = new Date(pickup.pickupDate);
    setNewPickupDate(date.toISOString().split('T')[0]);
    setNewPickupTime(date.toTimeString().substring(0, 5));
  };

  const handleSavePickupEdit = (pickupId: string) => {
    const newDateTime = new Date(`${newPickupDate}T${newPickupTime}`).toISOString();
    onUpdatePickupDateTime(pickupId, newDateTime);
    setEditingPickupId(null);
  };

  const handleNotificationClick = (notification: AppNotification) => {
      onMarkNotificationRead(notification.id);
      setShowNotifications(false);
      if (notification.type === 'new_pickup') {
          setActiveTab('pickups');
          // Ideally scroll to the pickup, but just switching tab is a good start
      }
  };

  const formatPhoneNumberForWhatsApp = (phone: string): string => {
    const digitsOnly = phone.replace(/\D/g, '');
    if (digitsOnly.length === 11 && !digitsOnly.startsWith('55')) {
        return `55${digitsOnly}`;
    }
    return digitsOnly;
  };

  const TabButton: React.FC<{tab: 'clients' | 'pickups', label: string}> = ({tab, label}) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
        activeTab === tab 
          ? 'bg-green-800 text-white' 
          : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
      }`}
    >
      {label}
    </button>
  );

  const getStatusChip = (status: PickupRequest['status']) => {
    switch (status) {
      case 'Agendado':
        return <span className="text-xs font-medium bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{status}</span>;
      case 'Confirmado':
        return <span className="text-xs font-medium bg-teal-100 text-teal-800 px-2 py-1 rounded-full">{status}</span>;
      case 'Reagendamento Proposto':
        return <span className="text-xs font-medium bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full whitespace-nowrap">Reag. Proposto</span>;
      case 'Concluído':
        return <span className="text-xs font-medium bg-green-100 text-green-800 px-2 py-1 rounded-full">{status}</span>;
      case 'Cancelado':
        return <span className="text-xs font-medium bg-red-100 text-red-800 px-2 py-1 rounded-full">{status}</span>;
    }
  }

  const renderPickupActions = (request: PickupRequest) => {
    const client = getClientById(request.userId);
    if (!client) return null;

    const formattedDate = new Date(request.pickupDate).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short'});

    if (editingPickupId === request.id) {
        return (
            <div className="pt-2 mt-2 border-t border-stone-100 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                    <Input type="date" value={newPickupDate} onChange={e => setNewPickupDate(e.target.value)} />
                    <Input type="time" value={newPickupTime} onChange={e => setNewPickupTime(e.target.value)} />
                </div>
                <div className="flex justify-end space-x-2">
                    <button onClick={() => setEditingPickupId(null)} className="text-sm font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 px-3 py-1 rounded-md transition-colors">Cancelar</button>
                    <button onClick={() => handleSavePickupEdit(request.id)} className="text-sm font-medium text-white bg-green-700 hover:bg-green-800 px-3 py-1 rounded-md transition-colors">Salvar</button>
                </div>
            </div>
        )
    }

    const whatsappBaseUrl = `https://wa.me/${formatPhoneNumberForWhatsApp(client.phone)}`;
    
    return (
        <div className="pt-2 mt-2 border-t border-stone-100 flex justify-end items-center space-x-2 flex-wrap gap-y-2">
            {request.status === 'Agendado' && (
                <>
                    <button onClick={() => handleEditPickupClick(request)} className="text-sm font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 px-3 py-1 rounded-md transition-colors">Editar</button>
                    <button onClick={() => onUpdateRequestStatus(request.id, 'Cancelado')} className="text-sm font-medium text-red-700 bg-red-100 hover:bg-red-200 px-3 py-1 rounded-md transition-colors">Cancelar</button>
                    <button onClick={() => onUpdateRequestStatus(request.id, 'Confirmado')} className="text-sm font-medium text-white bg-green-700 hover:bg-green-800 px-3 py-1 rounded-md transition-colors">Confirmar</button>
                </>
            )}
            {request.status === 'Confirmado' && (
                <>
                  <button onClick={() => handleEditPickupClick(request)} className="text-sm font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 px-3 py-1 rounded-md transition-colors">Editar</button>
                  <a href={`${whatsappBaseUrl}?text=${encodeURIComponent(`Olá, ${client.fullName}! Sua coleta de cacau de ${request.totalWeight}kg foi CONFIRMADA para ${formattedDate}.`)}`} target="_blank" rel="noopener noreferrer">
                      <button className="text-sm font-medium text-white bg-teal-500 hover:bg-teal-600 px-3 py-1 rounded-md transition-colors flex items-center space-x-1">
                          <WhatsappIcon className="w-4 h-4" />
                          <span>Notificar Cliente</span>
                      </button>
                  </a>
                </>
            )}
            {request.status === 'Reagendamento Proposto' && (
                <a href={`${whatsappBaseUrl}?text=${encodeURIComponent(`Olá, ${client.fullName}! Gostaríamos de propor um novo horário para sua coleta de ${request.totalWeight}kg: ${formattedDate}. Por favor, responda esta mensagem para confirmar.`)}`} target="_blank" rel="noopener noreferrer">
                    <button className="text-sm font-medium text-white bg-yellow-500 hover:bg-yellow-600 px-3 py-1 rounded-md transition-colors flex items-center space-x-1">
                        <WhatsappIcon className="w-4 h-4" />
                        <span>Notificar sobre Proposta</span>
                    </button>
                </a>
            )}
        </div>
    )
  }


  return (
    <div>
      <div className="flex justify-between items-center mb-6 relative">
        <Header />
        <div className="flex items-center space-x-3">
             <div className="relative">
                <button 
                    onClick={() => setShowNotifications(!showNotifications)}
                    className="p-2 bg-white rounded-full text-stone-600 hover:bg-stone-50 shadow-sm border border-stone-200"
                >
                    <BellIcon className="w-6 h-6" />
                    {unreadNotificationsCount > 0 && (
                        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full">
                            {unreadNotificationsCount}
                        </span>
                    )}
                </button>
                
                {showNotifications && (
                    <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-stone-100 z-50 overflow-hidden">
                        <div className="p-3 border-b border-stone-100 flex justify-between items-center bg-stone-50">
                            <h3 className="font-bold text-stone-700 text-sm">Notificações</h3>
                            {unreadNotificationsCount > 0 && (
                                <button onClick={() => onMarkAllNotificationsRead(company.id)} className="text-xs text-green-700 hover:underline">
                                    Marcar todas como lidas
                                </button>
                            )}
                        </div>
                        <div className="max-h-64 overflow-y-auto">
                            {notifications.length > 0 ? (
                                notifications.map(notif => (
                                    <div 
                                        key={notif.id} 
                                        onClick={() => handleNotificationClick(notif)}
                                        className={`p-3 border-b border-stone-100 cursor-pointer hover:bg-stone-50 transition-colors ${!notif.read ? 'bg-green-50/50' : ''}`}
                                    >
                                        <p className={`text-sm ${!notif.read ? 'font-semibold text-stone-800' : 'text-stone-600'}`}>
                                            {notif.message}
                                        </p>
                                        <p className="text-xs text-stone-400 mt-1">
                                            {new Date(notif.date).toLocaleString('pt-BR')}
                                        </p>
                                    </div>
                                ))
                            ) : (
                                <p className="p-4 text-center text-sm text-stone-400">Nenhuma notificação.</p>
                            )}
                        </div>
                    </div>
                )}
             </div>

            <button 
            onClick={onLogout} 
            className="px-4 py-2 text-sm font-medium text-red-700 bg-red-100 hover:bg-red-200 rounded-lg transition-colors"
            >
            Sair
            </button>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-2xl shadow-md mb-8">
        <h1 className="text-2xl font-bold text-stone-800">Painel da Empresa</h1>
        <p className="text-stone-500">Bem-vindo, <span className="font-semibold">{company.name}</span></p>
      </div>

      <div className="flex space-x-2 mb-6">
        <TabButton tab="pickups" label="Gerenciar Agendamentos" />
        <TabButton tab="clients" label="Gerenciar Clientes" />
      </div>

      {activeTab === 'pickups' && (
        <div>
            <h2 className="text-xl font-bold text-stone-700 mb-4">Agendamentos de Clientes</h2>
            {pickups.length > 0 ? (
                <div className="space-y-4">
                    {pickups.map(request => (
                        <Card key={request.id}>
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <p className="font-bold text-lg text-green-800">{request.totalWeight} kg</p>
                                    <p className="font-semibold text-stone-700">Cliente: {getClientById(request.userId)?.fullName || 'Desconhecido'}</p>
                                    <p className="text-sm text-stone-500">
                                        {new Date(request.pickupDate).toLocaleString('pt-BR', { dateStyle: 'long', timeStyle: 'short' })}
                                    </p>
                                    <p className="text-sm text-stone-500 mt-1">
                                      Endereço: {request.address}
                                    </p>
                                </div>
                                {getStatusChip(request.status)}
                            </div>
                            
                            {/* Exibe a foto no painel da empresa */}
                            {request.photoUrl && (
                                <div className="mt-2 mb-2">
                                    <p className="text-xs font-semibold text-stone-500 mb-1">Foto da Coleta:</p>
                                    <img 
                                        src={request.photoUrl} 
                                        alt="Foto da carga" 
                                        className="w-full h-40 object-cover rounded-lg border border-stone-200" 
                                    />
                                </div>
                            )}

                            {request.status === 'Confirmado' && request.confirmationCode && (
                                <div className="mt-2 pt-2 border-t border-stone-100">
                                    <p className="text-sm text-stone-600">Código de Entrega: <span className="font-bold text-stone-800 font-mono tracking-wider">{request.confirmationCode}</span></p>
                                    <p className="text-xs text-stone-500">Forneça este código ao cliente no momento da coleta.</p>
                                </div>
                            )}
                            {renderPickupActions(request)}
                        </Card>
                    ))}
                </div>
            ) : (
                <Card><p className="text-center text-stone-500">Nenhum agendamento encontrado.</p></Card>
            )}
        </div>
      )}

      {activeTab === 'clients' && (
         <div>
            <Card className="mb-8 border-2 border-stone-100">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-stone-700">
                        {editingClientId ? 'Editar Cliente' : 'Cadastrar Novo Cliente'}
                    </h2>
                    {editingClientId && (
                        <button onClick={resetClientForm} className="text-sm text-stone-500 hover:text-red-600">
                            Cancelar Edição
                        </button>
                    )}
                </div>
                <form onSubmit={handleClientFormSubmit} className="space-y-4">
                    <Input type="text" value={newClientFullName} onChange={(e) => setNewClientFullName(e.target.value)} placeholder="Nome completo do cliente" required />
                    <Input type="text" value={newClientNickname} onChange={(e) => setNewClientNickname(e.target.value)} placeholder="Apelido / Usuário para login" required />
                    <Input type="tel" value={newClientPhone} onChange={(e) => setNewClientPhone(e.target.value)} placeholder="Telefone / Whatsapp" required />
                    <Input type="text" value={newClientAddress} onChange={(e) => setNewClientAddress(e.target.value)} placeholder="Endereço Completo" required />
                    <div className="relative">
                      <Input 
                        type={showNewClientPassword ? "text" : "password"} 
                        value={newClientPassword} 
                        onChange={(e) => setNewClientPassword(e.target.value)} 
                        placeholder={editingClientId ? "Nova senha (deixe em branco para manter)" : "Senha para o cliente"} 
                        required={!editingClientId}
                        className="pr-10"
                      />
                       <button
                        type="button"
                        onClick={() => setShowNewClientPassword(!showNewClientPassword)}
                        className="absolute inset-y-0 right-0 flex items-center pr-3 text-stone-500 hover:text-stone-700"
                        aria-label={showNewClientPassword ? 'Ocultar senha' : 'Mostrar senha'}
                      >
                        {showNewClientPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                      </button>
                    </div>
                    <div className="flex gap-2">
                        {editingClientId && (
                             <Button type="button" onClick={resetClientForm} className="w-1/3 !bg-stone-200 !text-stone-700 hover:!bg-stone-300">
                                Cancelar
                            </Button>
                        )}
                        <Button type="submit" className="w-full">
                            {editingClientId ? 'Salvar Alterações' : 'Cadastrar Cliente'}
                        </Button>
                    </div>
                </form>
            </Card>
            <div>
                <h2 className="text-xl font-bold text-stone-700 mb-4">Clientes Cadastrados</h2>
                <div className="space-y-4">
                    {clients.map(client => (
                        <Card key={client.id}>
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <p className="font-semibold text-stone-800">{client.fullName}</p>
                                    <p className="text-sm text-stone-500">Usuário: {client.name} | Contato: {client.phone}</p>
                                    <p className="text-sm text-stone-500">Endereço: {client.address}</p>
                                </div>
                                <div className="flex flex-col items-end gap-2">
                                    <span className={`text-xs font-medium px-2 py-1 rounded-full self-center ${
                                        client.status === 'Ativo' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                                    }`}>
                                        {client.status}
                                    </span>
                                    <button 
                                        onClick={() => handleEditClientClick(client)}
                                        className="p-1.5 rounded-full bg-stone-100 text-stone-600 hover:bg-stone-200 hover:text-stone-800 transition-colors"
                                        title="Editar informações do cliente"
                                    >
                                        <EditIcon className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                            {client.status === 'Pendente' && (
                                <div className="pt-2 mt-2 border-t border-stone-100 flex justify-end">
                                    <button 
                                        onClick={() => onApproveClient(client.id)}
                                        className="text-sm font-medium text-white bg-green-700 hover:bg-green-800 px-3 py-1 rounded-md transition-colors"
                                    >
                                        Aprovar Cadastro
                                    </button>
                                </div>
                            )}
                        </Card>
                    ))}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default CompanyDashboard;
