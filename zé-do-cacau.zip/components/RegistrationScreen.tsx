
import React, { useState } from 'react';
import type { Company, User } from '../types';
import Header from './common/Header';
import Button from './common/Button';
import Input from './common/Input';
import { EyeIcon } from './icons/EyeIcon';
import { EyeOffIcon } from './icons/EyeOffIcon';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';

interface RegistrationScreenProps {
  companies: Company[];
  onRegister: (userData: Omit<User, 'id' | 'status'>) => void;
  onCancel: () => void;
}

const RegistrationScreen: React.FC<RegistrationScreenProps> = ({ companies, onRegister, onCancel }) => {
  const [fullName, setFullName] = useState('');
  const [nickname, setNickname] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [password, setPassword] = useState('');
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>(companies[0]?.id || '');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!fullName.trim() || !nickname.trim() || !phone.trim() || !address.trim() || !password.trim() || !selectedCompanyId) {
      setError('Por favor, preencha todos os campos.');
      return;
    }
    
    onRegister({
        name: nickname.trim(),
        fullName: fullName.trim(),
        phone: phone.trim(),
        address: address.trim(),
        password: password.trim(),
        companyId: selectedCompanyId
    });
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-8">
      <div className="w-full max-w-md flex items-center mb-4 px-2">
        <button 
          onClick={onCancel} 
          className="mr-3 p-2 rounded-full hover:bg-stone-200 transition-colors text-stone-600"
          aria-label="Voltar"
        >
          <ArrowLeftIcon className="w-6 h-6" />
        </button>
        <Header />
      </div>
      <div className="w-full max-w-md bg-white p-8 rounded-2xl shadow-lg">
        <h2 className="text-2xl font-bold text-center text-stone-700 mb-2">Crie sua Conta</h2>
        <p className="text-center text-stone-500 mb-6">Solicite seu cadastro na empresa parceira.</p>

        {error && <p className="bg-red-100 text-red-700 p-3 rounded-lg mb-4 text-sm text-center">{error}</p>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-stone-600 mb-1">Nome Completo</label>
            <Input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Digite seu nome completo"
              required
            />
          </div>
           <div>
            <label className="block text-sm font-medium text-stone-600 mb-1">Apelido (para login)</label>
            <Input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="Como você quer ser chamado?"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-600 mb-1">Telefone / Whatsapp</label>
            <Input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="(00) 90000-0000"
              required
            />
          </div>
           <div>
            <label className="block text-sm font-medium text-stone-600 mb-1">Endereço Completo</label>
            <Input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Rua, número, bairro, cidade"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-600 mb-1">Crie uma Senha</label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Uma senha simples de lembrar"
                required
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 flex items-center pr-3 text-stone-500 hover:text-stone-700"
                aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
              >
                {showPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-600 mb-1">Selecione sua Empresa</label>
            <select
              value={selectedCompanyId}
              onChange={(e) => setSelectedCompanyId(e.target.value)}
              className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-lg focus:ring-2 focus:ring-green-700 focus:border-green-700 transition"
              required
            >
              {companies.length === 0 ? (
                <option disabled>Nenhuma empresa disponível</option>
              ) : (
                companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)
              )}
            </select>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 pt-2">
            <Button type="button" onClick={onCancel} className="w-full bg-stone-200 text-stone-700 hover:bg-stone-300">
              Cancelar
            </Button>
            <Button type="submit" className="w-full">
              Solicitar Cadastro
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegistrationScreen;
