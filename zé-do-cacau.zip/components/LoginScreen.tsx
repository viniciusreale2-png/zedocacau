
import React, { useState } from 'react';
import type { User, Company } from '../types';
import Header from './common/Header';
import Button from './common/Button';
import Input from './common/Input';
import { EyeIcon } from './icons/EyeIcon';
import { EyeOffIcon } from './icons/EyeOffIcon';

interface LoginScreenProps {
  onAttemptLogin: (username: string, password: string) => { success: boolean; error?: string };
  onNavigateToRegister: () => void;
  availableUsers: User[];
  availableCompanies: Company[];
}

const LoginScreen: React.FC<LoginScreenProps> = ({ 
    onAttemptLogin, 
    onNavigateToRegister,
    availableUsers,
    availableCompanies
}) => {
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const result = onAttemptLogin(username.trim(), password.trim());
    if (!result.success) {
      setError(result.error || 'Usuário ou senha inválidos.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-8">
       <Header />
      <div className="w-full max-w-md bg-white p-8 rounded-2xl shadow-lg mt-6">
        <h2 className="text-2xl font-bold text-center text-stone-700 mb-2">Bem-vindo</h2>
        <p className="text-center text-stone-500 mb-6">Faça login para continuar.</p>
        
        {error && <p className="bg-red-100 text-red-700 p-3 rounded-lg mb-4 text-sm text-center">{error}</p>}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-stone-600 mb-1">Usuário</label>
            <Input
              type="text"
              id="username"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value)
                setError('')
              }}
              placeholder="Digite seu usuário"
              required
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-stone-600 mb-1">Senha</label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                id="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value)
                  setError('')
                }}
                placeholder="Sua senha"
                required
                className="pr-10"
              />
               <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 flex items-center pr-3 text-stone-500 hover:text-stone-700"
                aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
              >
                {showPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
              </button>
            </div>
          </div>
          <Button type="submit" className="w-full">
            Entrar
          </Button>
        </form>
        <div className="text-center mt-6">
            <p className="text-sm text-stone-500">
                Não tem uma conta?{' '}
                <button onClick={onNavigateToRegister} className="font-medium text-green-800 hover:underline focus:outline-none">
                    Cadastre-se
                </button>
            </p>
        </div>
      </div>

      {/* Demo Credentials Section - Dynamic List */}
      <div className="w-full max-w-md mt-6 p-4 bg-stone-200/50 rounded-xl text-stone-600 text-sm border border-stone-300/50 max-h-64 overflow-y-auto">
        <h3 className="font-bold mb-2 text-stone-700 text-xs uppercase tracking-wider text-center sticky top-0 bg-stone-200/90 py-1">Credenciais Salvas (Demo)</h3>
        <div className="grid grid-cols-2 gap-x-4 gap-y-4 text-xs">
            <div>
                <p className="font-semibold text-green-800 mb-1 border-b border-green-800/20 pb-0.5 sticky top-0 bg-transparent">Clientes</p>
                {availableUsers.length > 0 ? (
                    availableUsers.map(u => (
                        <div key={u.id} className="flex justify-between mb-1">
                            <span className="font-medium truncate mr-2" title={u.name}>{u.name}</span> 
                            <span className="text-stone-500">{u.password || '****'}</span>
                        </div>
                    ))
                ) : (
                    <p className="text-stone-400 italic">Nenhum cliente</p>
                )}
            </div>
             <div>
                <p className="font-semibold text-stone-800 mb-1 border-b border-stone-800/20 pb-0.5 sticky top-0 bg-transparent">Empresas</p>
                {availableCompanies.length > 0 ? (
                    availableCompanies.map(c => (
                        <div key={c.id} className="flex justify-between mb-1">
                             <div className="flex flex-col overflow-hidden">
                                <span className="font-medium truncate" title={c.username}>{c.username}</span>
                             </div>
                             <span className="text-stone-500">{c.password || '****'}</span>
                        </div>
                    ))
                ) : (
                    <p className="text-stone-400 italic">Nenhuma empresa</p>
                )}
                
                 <div className="mt-3 pt-2 border-t border-stone-300/50">
                    <p className="font-semibold text-stone-800 mb-1">Super Admin</p>
                    <div className="flex justify-between"><span className="font-medium">adm</span> <span>123456</span></div>
                 </div>
            </div>
        </div>
      </div>

    </div>
  );
};

export default LoginScreen;
